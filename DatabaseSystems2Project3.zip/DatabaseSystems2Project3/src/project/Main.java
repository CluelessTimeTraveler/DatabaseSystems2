package project;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {

        CommandHandler cmd = new CommandHandler();
        cmd.handleCommands();
        System.out.println("Done");
    }
}
