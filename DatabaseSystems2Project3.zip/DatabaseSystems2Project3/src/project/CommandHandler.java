package project;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.*;

public class CommandHandler {


    public void handleCommands() throws IOException {
        System.out.println("The program is ready for the next command");
        BufferedReader reader = null;
        boolean keepGoing = true;
        String command = "";
        Scanner keyboard = new Scanner(System.in);
        while(keepGoing){
            command = keyboard.nextLine();

            //Create Index command
            if(command.matches("SELECT A.Col1, A.Col2, B.Col1, B.Col2 FROM A, B WHERE A.RandomV = B.RandomV")){
                long start = Instant.now().toEpochMilli();
                hashBasedJoin();
                long end = Instant.now().toEpochMilli();
                System.out.println("Total time = " + (end-start) + " milliseconds");
                continue;

            }

            if(command.matches("SELECT count\\(\\*\\) FROM A, B WHERE A.RandomV > B.RandomV")){
                long start = Instant.now().toEpochMilli();
                BlockLvlLoopJoin();
                long end = Instant.now().toEpochMilli();
                System.out.println("Total time = " + (end-start) + " milliseconds");
                continue;
            }

            if(command.matches("Fast")){
                long start = Instant.now().toEpochMilli();
                BlockLvlLoopJoinFast();
                long end = Instant.now().toEpochMilli();
                System.out.println("Total time = " + (end-start) + " milliseconds");
                continue;
            }

            if(command.matches("(SELECT Col2, (SUM\\(RandomV\\)|AVG\\(RandomV\\)) FROM (A|B) GROUP BY Col2)")) {
                String[] splitCommand = command.split(" ", -1);
                String operator = splitCommand[2].substring(0, 3);
                String dataset = splitCommand[4];
                long start = Instant.now().toEpochMilli();
                hashBasedAggregation(operator,dataset);
                long end = Instant.now().toEpochMilli();
                System.out.println("Total time = " + (end-start) + " milliseconds");
                continue;
            }

            if(command.matches("(EXIT)")){
                keepGoing = false;
                continue;
            }
            System.out.println("Invalid command");

        }


    }


    public void hashBasedJoin() throws IOException {
        HashMap<Integer,ArrayList<Record>> hashTable = new HashMap<>(500);

        for(String[] file : loadFiles("Project3Dataset-A")){
            for(int pos = 0; pos < 100; pos++){
                Record r = new Record(file[pos]);

                ArrayList<Record> entries = hashTable.get(r.getRandomV());
                if(entries == null){
                    entries = new ArrayList();
                    entries.add(r);

                }else{
                    entries.add(r);
                }
                hashTable.put(r.getRandomV(),entries);
            }

        }

        for(String[] file : loadFiles("Project3Dataset-B")){
            for(int pos = 0; pos < 100; pos++){
                Record recordB = new Record(file[pos]);
                ArrayList<Record> bucketOfA = hashTable.get(recordB.getRandomV());
                if(bucketOfA == null){
                    continue;
                }
                for(Record r : bucketOfA){
                    if(r.getRandomV()==recordB.getRandomV()){
                        System.out.println(r.getColumn(1)+ " " +r.getColumn(2) + " " + recordB.getColumn(1) + " " + recordB.getColumn(2));
                    }
                }
            }

        }


    }

    public void BlockLvlLoopJoin() throws IOException {

        long count = 0;
        for(int aFile = 1; aFile<100; aFile++){
            System.out.println("On file A" + aFile);
            String[] fileFromA = loadSingleFile("Project3Dataset-A",Integer.toString(aFile));
            for(int aRecord = 1; aRecord<100; aRecord++){
                Record aRecOb = new Record(fileFromA[aRecord]);
                for(int bFile = 1; bFile<100; bFile++){
                    String[] fileFromB = loadSingleFile("Project3Dataset-B",Integer.toString(bFile));
                    for(int r = 1; r<100; r++){
                        Record bRecOb = new Record(fileFromB[r]);
                        if(aRecOb.getRandomV()>bRecOb.getRandomV()){
                            count++;
                        }

                    }
                }
            }
        }
        System.out.println("Count of records matching condition: " + count);
    }

    public void BlockLvlLoopJoinFast() throws IOException{

        List<String[]> memoryRecordA  = loadFiles("Project3Dataset-A");
        List<String[]> diskRecordB = loadFiles("Project3Dataset-B");
        long count = 0;
        for(String[] fileA : memoryRecordA){
            System.out.println("On file A" + memoryRecordA.indexOf(fileA));
            for(int a = 1; a<100; a++){
                Record rA = new Record(fileA[a]);
                for(String[] fileB : diskRecordB){
                    for(int b = 1; b<100; b++){
                        Record rB = new Record(fileA[b]);
                        if(rA.getRandomV() > rB.getRandomV()){
                            count++;
                        }
                    }

                }
            }
        }
        System.out.println("Count of records matching condition: " + count);
    }

    void hashBasedAggregation(String operator, String dataset) throws IOException{

        class AggregateValues{
            public int numberOfValues = 0;
            public long sum = 0;
            public long average(){
                return (sum/numberOfValues);
            }
        }


        HashMap<String,AggregateValues> hashTable = new HashMap<>();

        for(String[] file : loadFiles("Project3Dataset-" + dataset)){
            for(int pos = 0; pos < 100; pos++){
                Record r = new Record(file[pos]);
                AggregateValues av = hashTable.get(r.getName());
                if(av == null){
                    av = new AggregateValues();
                    av.sum+=r.getRandomV();
                    av.numberOfValues++;

                }else{
                    av.sum+=r.getRandomV();
                    av.numberOfValues++;
                }
                hashTable.put(r.getName(),av);

            }

        }

        switch(operator){
            case "SUM":
                hashTable.forEach((k,v)->{
                    System.out.println("Col2: " + k + " Sum: " + v.sum);
                });
                break;
            case "AVG":
                hashTable.forEach((k,v)->{
                    System.out.println("Col2: " + k + " Avg: " + v.average());
                });
                break;
        }





    }


    String[] loadSingleFile(String dataset, String fileNumber) throws IOException {
        String data = new String(Files.readAllBytes(Paths.get( dataset + "\\" + dataset.substring(16) + fileNumber + ".txt")));
        String[] splitData = data.split("\\.\\.\\.",-1);
        for(int pos = 0; pos < 100; pos++){
            String s = splitData[pos];
            s = s + "...";
        }
        return splitData;
    }


    List<String[]> loadFiles(String dataset) throws IOException {
        ArrayList<String[]> recordFiles = new ArrayList<>();
        for(int x = 1;x<100;x++){
            String data = new String(Files.readAllBytes(Paths.get( dataset + "\\" + dataset.substring(16) + x + ".txt")));
            String[] splitData = data.split("\\.\\.\\.",-1);
            for(int pos = 0; pos < 100; pos++){
                String s = splitData[pos];
                s = s + "...";
            }
            recordFiles.add(splitData);
        }
        return recordFiles;
    }

}
