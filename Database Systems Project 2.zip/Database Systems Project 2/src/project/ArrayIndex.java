package project;

import java.util.ArrayList;

public class ArrayIndex extends Index{
    private ArrayList<ArrayList<RecordLocation>> index;

    public ArrayIndex() {
        this.index = new ArrayList<>();
        for(int x = 0; x<5001; x++){
            index.add(x, new ArrayList<RecordLocation>());
        }

    }

    public void add(String record, RecordLocation location){
        ArrayList<RecordLocation> newList = index.get(extractRandomVFromString(record));
        newList.add(location);
        index.set(extractRandomVFromString(record),newList);
    }

    public ArrayList<RecordLocation> get(int randomV){
        return index.get(randomV);
    }



}
