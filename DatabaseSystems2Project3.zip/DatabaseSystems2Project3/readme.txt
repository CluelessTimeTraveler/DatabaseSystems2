Mario Castro, 755524129
Section 1

javac -d CompiledProject -sourcepath src -cp CompiledProject src\project\Main.java
java -cp CompiledProject project.Main

If above doesnt work, a pre-compiled jar is included.

Section 2
All parts are working to the best of my knowledge.
For Building a block level nested loop join, following the algorithm as described in section 3, it goes very slowly.
I wasn't sure if this was intentional but I included a command "Fast" that runs a variation that simulates reading
each file one by one but instead has already read in both Datasets into a list of string arrays. Each string array
represents a single file and each string in the array is a record. The command specified in the assignment runs the
accurate but slower algorithm, "Fast" runs the fast algorithm. They return slightly different values for the count
and I could not figure out which one was accurate.

My design consists of a CommandHandler class that processes commands and executes the appropriate functions.
Design assumes datasets are in the working directory.
Records are stored in an object of type Record with fields to help process individual records

