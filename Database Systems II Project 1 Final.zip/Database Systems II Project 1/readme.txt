Compile and run with
javac -d CompiledProject -sourcepath src -cp CompiledProject src\com\company\Main.java
java -cp CompiledProject com.company.Main SIZE_OF_BUFFER_POOL (optional: true for debug mode)

Debug mode prints out the bufferpool after every command and only accepts input through a file called textcase.txt
that must be present in the working directory. An example testcase.txt is given. 

Example:

Debug mode on
java -cp BufferManager com.company.Main 3 true

Block Files must exist inside of directory Files.  
If commands do not work to compile, precompiled jar is included, run with java -jar PreCompiled.Jar SIZE
