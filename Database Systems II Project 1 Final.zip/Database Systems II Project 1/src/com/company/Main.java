package com.company;

import BufferManager.BufferManagementSystem;

public class Main {

    public static void main(String[] args) {
	// write your code here
//        boolean continueAcceptingCommands = true;
//        while(continueAcceptingCommands){
//
//            if()
//
//
//        }
        boolean debugVal = false;
        if(args.length == 2){
            debugVal = Boolean.parseBoolean(args[1]);
        }

        BufferManagementSystem bms = new BufferManagementSystem(Integer.parseInt(args[0]),debugVal);
        //bms.printBufferPool();
        bms.initalize();
        bms.handleCommands();

    }
}
