Mario Castro, 755524129
Section 1

javac -d CompiledProject -sourcepath src -cp CompiledProject src\project\Main.java
java -cp CompiledProject project.Main

Section 2
All parts are working to the best of my knowledge
Section 3
My design consists of an IndexManager Class that handles commands and has two subclasses of Index,
HashIndex and ArrayIndex. Hash Index is a HashMap that binds a randomV value to a list of objects of type RecordLocation.
Record location contains the file number and offset for a particular record with the specified randomV value.
ArrayIndex is similar except it consists of an array of lists of record location instead of a hashmap of lists.
The design assumes a folder called Project2Dataset exists with the files labeled F#.txt of 1-99
