package BufferManager;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class BufferManagementSystem {
    int poolSize;
    BufferPool bufferPool;
    String filePath;
    boolean debugMode;

    public BufferManagementSystem(int poolSize, boolean debug) {
        this.poolSize = poolSize;
        bufferPool = new BufferPool(poolSize);
        debugMode = debug;

    }

    /**
     * Initializes the buffer management system
     */
    public void initalize(){
        Scanner keyboard = new Scanner(System.in);

//        System.out.println("Enter path to block files...");
//        String path = keyboard.next();

        filePath = "Files";

        System.out.println("Path to block files entered: " + filePath);
        System.out.println("Buffer pool of size: " + poolSize);
        System.out.println("All frames are empty\n");
        System.out.println("Buffer Pool----------------");
        printBufferPool();
        //System.out.println("The program is ready for the next command");
    }


    public void printBufferPool(){
        System.out.println(bufferPool.toString());
    }

    /**
     * Handles command input
     */
    public void handleCommands(){
        System.out.println("The program is ready for the next command");
        boolean keepGoing = true;
        String command = "";
        BufferedReader reader = null;


        if(debugMode) {

            try {
                reader = new BufferedReader(new FileReader("testcase.txt"));

            } catch (FileNotFoundException e) {
                System.out.println("Error reading test case file, cannot find testcase.txt");
                throw new RuntimeException();
            }
        }

        Scanner keyboard = new Scanner(System.in);
        while(keepGoing){

            if(debugMode){
                try{
                    command = reader.readLine();
                }catch(IOException e){
                    System.out.println("Something went wrong");
                    throw new RuntimeException();
                }
            }else{
                command = keyboard.nextLine();
            }



            if(!command.matches("(^(GET|SET|PIN|UNPIN|EXIT))[ ]*[0-9]*[ ]?(.*)")){
                System.out.println("Invalid Command: " + command);
                continue;
            }
            System.out.println("\nReceived command: " + command);
            String[] splitCommand = command.split(" ",-1);

            switch(splitCommand[0]){
                case "GET":
                    get(Integer.parseInt(splitCommand[1]));
                    break;
                case "SET":
                    String inputtedRecordData = splitCommand[2];
                    for(int i = 3; i < splitCommand.length; i++){
                        inputtedRecordData = inputtedRecordData + " " + splitCommand[i];
                    }
                    //set(Integer.parseInt(splitCommand[1]),splitCommand[2]);
                    set(Integer.parseInt(splitCommand[1]),inputtedRecordData);

                    break;
                case "PIN":
                    pin(Integer.parseInt(splitCommand[1]));
                    break;
                case "UNPIN":
                    unpin(Integer.parseInt(splitCommand[1]));
                    break;
                case "EXIT":
                    return;
            }
            if(debugMode){
                System.out.println(bufferPool.toString());
            }
        }
        keyboard.close();

    }

    /**
     * Get command as specified
     * @param recordID
     */
    public void get(int recordID){

        System.out.println("Getting record " + recordID);
        //System.out.println("Block found already in memory, data for record needed is...");
        System.out.println("Record: " + putRecordIntoPool(recordID));
    }

    /**
     * Helper method for putting a record into the pool
     * @param recordID
     * @return String that was put into pool
     */
    private String putRecordIntoPool(int recordID) {
        int blockID = calculateBlockID(recordID);
        System.out.println("Record " + recordID + " is located in file and block " + blockID);

        int presentBlock = bufferPool.findBlock(blockID);
        if(presentBlock == -1){
            System.out.println("Block " + blockID + " is not currently in the pool");
            System.out.println("Will try and load...");
            int emptyFrameIndex = bufferPool.findEmpty();
            if(emptyFrameIndex == -1){
                System.out.println("Unable to find empty slot, will try and evict");
                int evictableFrameIndex = bufferPool.findEvictable();
                if(evictableFrameIndex == -1){
                    System.out.println("Unable to get record " + recordID + " and no frame can be evicted because memory buffers are full");
                    return "";
                }
                //bufferPool.pool.remove(evictableFrameIndex);
                System.out.println("Will evict Block " + bufferPool.pool.get(evictableFrameIndex).getBlockID() + " from Frame " + evictableFrameIndex);
                evict(evictableFrameIndex);
                System.out.println("Evict successful, inserting block " + blockID);
                InsertFileBlockIntoPool(blockID, evictableFrameIndex);
                return bufferPool.pool.get(evictableFrameIndex).getRecordOfNumber(recordID);

            }else{
                System.out.println("Empty slot found at Frame " + emptyFrameIndex);
                //bufferPool.pool.remove(emptyFrameIndex);
                evict(emptyFrameIndex);
                System.out.println("Inserting block " + blockID + " into Frame " + emptyFrameIndex);
                InsertFileBlockIntoPool(blockID,emptyFrameIndex);
                return bufferPool.pool.get(emptyFrameIndex).getRecordOfNumber(recordID);
            }

        }else{
            System.out.println("Record " + recordID + " is already in memory in Frame " + presentBlock);
            return bufferPool.pool.get(presentBlock).getRecordOfNumber(recordID);
        }






    }

    /**
     * Helper method for loading a block into the pool
     * @param blockID
     */
    private void putBlockIntoPool(int blockID){
        int presentBlock = bufferPool.findBlock(blockID);
        if(presentBlock == -1){
            System.out.println("Block " + blockID + " not currently in the pool");
            System.out.println("Will try and load...");
            int emptyFrameIndex = bufferPool.findEmpty();
            if(emptyFrameIndex == -1){
                System.out.println("Unable to find empty slot, will try and evict");
                int evictableFrameIndex = bufferPool.findEvictable();
                if(evictableFrameIndex == -1){
                    System.out.println("Unable to load block " + blockID + " because no frame can be evicted");
                    return;
                }
                //bufferPool.pool.remove(evictableFrameIndex);
                System.out.println("Will evict Block " + bufferPool.pool.get(evictableFrameIndex).getBlockID() + " from Frame " + evictableFrameIndex);
                evict(evictableFrameIndex);
                System.out.println("Evict successful, inserting block " + blockID);
                InsertFileBlockIntoPool(blockID, evictableFrameIndex);
                return;

            }else{
                System.out.println("Empty slot found at Frame " + emptyFrameIndex);
                //bufferPool.pool.remove(emptyFrameIndex);
                evict(emptyFrameIndex);
                System.out.println("Inserting block " + blockID + " into Frame " + emptyFrameIndex);
                InsertFileBlockIntoPool(blockID,emptyFrameIndex);
                return;
            }

        }else{
            System.out.println("Block " + blockID + " is already in memory");
            return;
        }
    }

    /**
     * Helper method to insert block into specific Frame index
     * @param blockID
     * @param indexToInsert
     */
    private void InsertFileBlockIntoPool(int blockID, int indexToInsert) {
        System.out.println("Storing Block " + blockID + " in Frame " + indexToInsert);
        String data = "";
        try{
            data = new String(Files.readAllBytes(Paths.get(filePath + "\\F" + blockID + ".txt")));
        } catch (IOException e) {
            System.out.println("Error: Unable to read file at path: " + filePath + "\\F" + blockID + ".txt");
            return;
        }

        Frame loadableFrame = Frame.newFrameFrom(data, blockID);
        bufferPool.pool.add(indexToInsert, loadableFrame);
    }

    /**
     * Set command as specified
     * @param recordID
     * @param recordData
     */
    public void set(int recordID, String recordData){
        System.out.println("Setting " + recordID + " to " + recordData);
        //get(recordID);
        putRecordIntoPool(recordID);
        int frameOfRecordID = bufferPool.findBlock(calculateBlockID(recordID));
        if(frameOfRecordID == -1){
            System.out.println("Record not in pool, unable to access");
        }else{
            bufferPool.pool.get(frameOfRecordID).updateRecord(recordID,recordData);
        }

    }

    /**
     * Helper method for setting the pin status of a block
     * @param blockID
     * @param status
     */
    private void setPinStatus(int blockID, boolean status){
        //System.out.println("Pinning " + blockID);
        if(status == true){
            putBlockIntoPool(blockID);
        }
        int frameOfBlockID = bufferPool.findBlock(blockID);
        if(frameOfBlockID == -1){
            System.out.println("Block " + blockID + " is not in the pool and its pin status cannot be changed");
            return;
        }
        if(bufferPool.pool.get(frameOfBlockID).isPinnedFlag() && status){
            System.out.println("Block " + blockID + "'s pin status is already true");
        }
        if(!bufferPool.pool.get(frameOfBlockID).isPinnedFlag() && status){
            System.out.println("Block " + blockID + "'s pin status set to true");
        }
        if(bufferPool.pool.get(frameOfBlockID).isPinnedFlag() && !status){
            System.out.println("Block " + blockID + "'s pin status set to false");
        }
        if(!bufferPool.pool.get(frameOfBlockID).isPinnedFlag() && !status){
            System.out.println("Block " + blockID + "'s pin status is already false");
        }
        bufferPool.pool.get(frameOfBlockID).setPinnedFlag(status);
        //IF NOT ALREADY...
        //System.out.println("File " + blockID + " pin status set to " + status);
    }

    /**
     * Pin command as specified
     * @param blockID
     */
    public void pin(int blockID){
        System.out.println("Pinning " + blockID);
        setPinStatus(blockID,true);
    }

    /**
     * Unpin command as specified
     * @param blockID
     */
    public void unpin(int blockID) {
        System.out.println("Unpinning " + blockID);
        setPinStatus(blockID,false);
    }

    /**
     * Helper method for calculating blockID from record ID
     * @param recordID
     * @return blockID for given recordID
     */
    static int calculateBlockID(int recordID){
        return recordID/100 + 1;
    }


    /**
     * Helper method for evicting a frame index and writing the contents to the disk
     * @param frameIndex
     */
    public void evict(int frameIndex){
        Frame toBeEvicted = bufferPool.pool.get(frameIndex);
        if(toBeEvicted.isDirtyFlag() == true){
//            String filePath = toBeEvicted.getBlockID()
            String content = toBeEvicted.toFileString();
            try{
                FileWriter writer = new FileWriter(filePath + "\\F" + toBeEvicted.getBlockID() + ".txt");
                writer.write(content);
                writer.close();
            }catch (IOException e) {
                System.out.println("Error: Unable to write file at path: " + filePath + "\\F" + toBeEvicted.getBlockID() + ".txt");
                e.printStackTrace();
            }
        }
        bufferPool.pool.remove(frameIndex);
    }

}
