package BufferManager;

import java.util.ArrayList;

/**
 * The class representing a frame of the buffer pool
 */
class Frame {
    private ArrayList<String> data;
    private boolean dirtyFlag;
    private boolean pinnedFlag;
    private int blockID;

    public ArrayList<String> getData() {
        return data;
    }

    public void setData(ArrayList<String> data) {
        this.data = data;
    }

    public boolean isDirtyFlag() {
        return dirtyFlag;
    }

    public void setDirtyFlag(boolean dirtyFlag) {
        this.dirtyFlag = dirtyFlag;
    }

    public boolean isPinnedFlag() {
        return pinnedFlag;
    }

    public void setPinnedFlag(boolean pinnedFlag) {
        this.pinnedFlag = pinnedFlag;
    }

    public int getBlockID() {
        return blockID;
    }

    public void setBlockID(int blockID) {
        this.blockID = blockID;
    }

    /**
     * Loads a frame from a given string
     * @param block
     * @param sizeOfRecord
     */
    public void load(String block, int sizeOfRecord){
        //String[] splitBlockByRecord = block.split(".");
        for(int i = 0; i<block.length(); i = i + sizeOfRecord){
            this.data.add(block.substring(i,i+sizeOfRecord));
        }
    }

    /**
     * Generates a string of a frame's data
     * @return
     */
    public String toFileString(){
        String result = "";
        for(String record : data){
            result = result + record;
        }
        return result;
    }


    /**
     * Returns the string record of a given number
     * @param recordNumber
     * @return
     */
    public String getRecordOfNumber(int recordNumber){
        return data.get((recordNumber%100)-1);
    }

    /**
     * Updates a given string record
     * @param recordNumber
     * @param recordToSave
     */
    public void updateRecord(int recordNumber, String recordToSave){
        data.remove((recordNumber%100)-1);
        data.add((recordNumber%100)-1,recordToSave);
        this.dirtyFlag = true;
    }

    private Frame(){

    }


    /**
     * Gives empty properly initialized Frame
     * @return
     */
    public static Frame initBlankFrame(){
        Frame newFrame = new Frame();
        newFrame.setBlockID(-1);
        newFrame.setPinnedFlag(false);
        newFrame.setData(new ArrayList<>());
        newFrame.setDirtyFlag(false);
        return newFrame;
    }

    /**
     * Gives an Frame based on the given data
     * @param data
     * @param blockID
     * @return
     */
    public static Frame newFrameFrom(String data, int blockID){
        Frame newFrame = initBlankFrame();
        newFrame.setBlockID(blockID);
        newFrame.setPinnedFlag(false);
        newFrame.load(data,40);
        newFrame.setDirtyFlag(false);
        return newFrame;
    }

    public String toString(){
        return "Data in Frame(" + data.toString() + "), \nDirty Flag(" + dirtyFlag + "), Pinned Flag(" + pinnedFlag + "), Block ID(" + blockID + ")\n\n";
    }



}
