package BufferManager;

import java.util.ArrayList;

class BufferPool {
    ArrayList<Frame> pool;

    BufferPool(int size){
        pool = new ArrayList<>(size);
//        for(Frame frame : pool){
//            frame = Frame.initNewFrame();
//        }

        for(int x = 0; x < size; x++){
            pool.add(Frame.initBlankFrame());
        }

    }


    /**
     * Finds if a given block is in memory
     * @param blockID
     * @return -1 if not in memory, index of block if in memory
     */
    int findBlock(int blockID){
        for(int index = 0; index < pool.size(); index++){
            if(pool.get(index).getBlockID() == blockID){
                //System.out.println("Block found at: " + index);
                return index;
            }
        }
        return -1;
    }

    //-1 means unable to find empty block and cannot evict

    /**
     * Finds the first empty frame
     * @return -1 if no empty frame, index of empty frame if found
     */
    int findEmpty(){

        int index = findBlock(-1);
        if(index != -1){
            return index;
        }else{
            //System.out.println("Unable to find empty block");
            return -1;
        }

    }

    /**
     * Finds the first evictable frame
     * @return -1 if no evictable frame, Index of evictable frame if found
     */
    int findEvictable(){
        for(int index = 0; index < pool.size(); index++){
            if(pool.get(index).isPinnedFlag() == false){
                return index;
            }
        }
        //System.out.println("Unable to evict any blocks, all pinned");
        return -1;
    }

    public String toString(){
        String results = "";
        for(Frame f : pool){
            results = results + "Frame " + pool.indexOf(f) + " ~ " + f.toString();
        }
        return results;
    }


}
