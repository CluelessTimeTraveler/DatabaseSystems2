package project;

public class Index{

    int extractRandomVFromString(String record){
        int randomV = Integer.parseInt(record.substring(33,37));
        return randomV;
    }
}
