package project;

public class Record {
    int fileNum;
    int recNum;


    String name;
    String address;
    int randomV;

    String fileSignal;

    public String getColumn(int columnNumber){
        switch(columnNumber){
            case 1:
                return fileSignal+fileNum+"-Rec"+recNum;
            case 2:
                return "Name"+name;
            case 3:
                return "address"+address;
            case 4:
                return String.valueOf(randomV);
            default:
                return null;
        }
    }

    public int getFileNum() {
        return fileNum;
    }

    public void setFileNum(int fileNum) {
        this.fileNum = fileNum;
    }

    public int getRecNum() {
        return recNum;
    }

    public void setRecNum(int recNum) {
        this.recNum = recNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getRandomV() {
        return randomV;
    }

    public void setRandomV(int randomV) {
        this.randomV = randomV;
    }



    private Record(int fileNum, int recNum, String name, String address, int randomV) {
        this.fileNum = fileNum;
        this.recNum = recNum;
        this.name = name;
        this.address = address;
        this.randomV = randomV;
    }

    public Record(String stringRecord){
        this.fileSignal = stringRecord.substring(0,1);
        this.fileNum = Integer.parseInt(stringRecord.substring(1,3));
        this.recNum = Integer.parseInt(stringRecord.substring(7,10));
        this.name = stringRecord.substring(16,19);
        this.address = stringRecord.substring(28,31);
        this.randomV =  Integer.parseInt(stringRecord.substring(33,37));


    }

    @Override
    public String toString() {
        String retVal = "";
        for(int i = 1; i < 5; i++){
            retVal = retVal+getColumn(i);
            if(i==4){
                retVal+="...";
            }else{
                retVal+=",";
            }
        }
        return retVal;
    }


}
