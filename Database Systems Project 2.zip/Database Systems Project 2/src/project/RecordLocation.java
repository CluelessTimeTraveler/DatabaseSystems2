package project;

public class RecordLocation {
    int fileNum;
    int offSet;

    public RecordLocation(int fileNum, int offSet) {
        this.fileNum = fileNum;
        this.offSet = offSet;
    }
}
