package project;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class IndexManager {
    ArrayIndex arrayIndex;
    HashIndex hashIndex;
    boolean createdIndex;

    public IndexManager(){
        arrayIndex = new ArrayIndex();
        hashIndex = new HashIndex();
        createdIndex = false;
    }

    public void loadFiles() throws IOException {
        for(int x = 1;x<100;x++){
            String data = new String(Files.readAllBytes(Paths.get( "Project2Dataset\\F" + x + ".txt")));
            String[] splitData = data.split("\\.\\.\\.",-1);
            //int position = 0;
            for(int pos = 0; pos < 100; pos++){
                String s = splitData[pos];
                s = s + "...";
                System.out.println("Adding: " + s);
                arrayIndex.add(s,new RecordLocation(x,pos));
                hashIndex.add(s,new RecordLocation(x,pos));
            }
        }
        createdIndex = true;
    }

    public void handleCommands() throws IOException {
        System.out.println("The program is ready for the next command");
        BufferedReader reader = null;
        boolean keepGoing = true;
        String command = "";
        Scanner keyboard = new Scanner(System.in);
        while(keepGoing){
            command = keyboard.nextLine();

            //Create Index command
            if(command.matches("(CREATE INDEX ON RandomV)")){
                createIndex();
                continue;
            }

            if(command.matches("(SELECT \\* FROM Project2Dataset WHERE RandomV = [0-9]*)")){

                String[] splitCommand = command.split(" ",-1);
                int num1 = Integer.parseInt(splitCommand[7]);
                selectSingleValue(num1);
                continue;
            }

            if(command.matches("(SELECT \\* FROM Project2Dataset WHERE RandomV > [0-9]* AND RandomV < [0-9]*)")){
                String[] splitCommand = command.split(" ",-1);
                int num1 = Integer.parseInt(splitCommand[7]);
                int num2 = Integer.parseInt(splitCommand[11]);
                selectRangeValue(num1,num2);
                continue;
            }

            if(command.matches("(SELECT \\* FROM Project2Dataset WHERE RandomV != [0-9]*)")){
                String[] splitCommand = command.split(" ",-1);
                int num1 = Integer.parseInt(splitCommand[7]);
                selectUnequalToValue(num1);
                continue;
            }

            if(command.matches("(EXIT)")){
                keepGoing = false;
                continue;
            }
            System.out.println("Invalid command");

        }


    }


    void createIndex(){
        try{
            loadFiles();
        } catch (IOException e) {
            System.out.println("Unable to create index: Failure to read in files");
            e.printStackTrace();
        }
        System.out.println("The hash-based and array-based indexes are built");
    }


    void selectSingleValue(int value) throws IOException {
        System.out.println("Using Hash Index...");
        long start = Instant.now().toEpochMilli();
        int filesRead = 0;
        if(value < 1 || value > 5000){
            System.out.println("No record with that value");
        }else{
            ArrayList<RecordLocation> locations = hashIndex.get(value);
            if(locations == null){
                System.out.println("Not found in index, no record matching RandomV of " + value);
                return;
            }
            HashMap<Integer,byte[]> memoryPages = new HashMap<>();
            filesRead = getFilesRead(locations,memoryPages);
        }
        long end = Instant.now().toEpochMilli();
        System.out.println("Files/Blocks read: " + filesRead);
        System.out.println("Total time = " + (end-start) + " milliseconds");
    }

    private int getFilesRead(ArrayList<RecordLocation> locations, HashMap<Integer,byte[]> memoryPages) throws IOException {

        int filesRead = 0;
        for(RecordLocation location : locations) {
            byte[] inputBuffer = new byte[4000];
            if(memoryPages.get(location.fileNum) != null){
                //System.out.println("Found file:"+location.fileNum+" in memory.");
                byte[] savedBuffer = memoryPages.get(location.fileNum);
                InputStream fromMemory = new ByteArrayInputStream(savedBuffer);
                fromMemory.skip(location.offSet*40);
                fromMemory.read(inputBuffer,0,40);
                fromMemory.close();
                System.out.println("Record: " + new String(inputBuffer));
            }else{
                File file = new File("Project2Dataset\\F" + location.fileNum + ".txt");
                InputStream is = new FileInputStream(file);
                is.read(inputBuffer,0,4000);
                memoryPages.put(location.fileNum,inputBuffer);
                is.close();

                InputStream isFromMemory = new ByteArrayInputStream(inputBuffer);
                isFromMemory.skip(location.offSet*40);
                byte[] tempBuffer = new byte[40];
                isFromMemory.read(tempBuffer,0,40);
                isFromMemory.close();
                System.out.println("Record: " + new String(tempBuffer));
                filesRead++;
            }
        }
        return filesRead;
    }

    void selectRangeValue(int smallNum, int largeNum) throws IOException {
        System.out.println("Using Array Index...");
        int filesRead = 0;
        long start = Instant.now().toEpochMilli();
        if(smallNum < 1 || smallNum > 5000 || largeNum < 1 || largeNum > 5000 ){
            System.out.println("No record with that value");
        }else{
            HashMap<Integer,byte[]> memoryPages = new HashMap<>();
            for(int x = smallNum; x <= largeNum; x++){
                ArrayList<RecordLocation> locations = arrayIndex.get(x);
                filesRead = filesRead + getFilesRead(locations,memoryPages);
            }
        }
        long end = Instant.now().toEpochMilli();
        System.out.println("Files/Block read: " + filesRead);
        System.out.println("Total time = " + (end-start) + " milliseconds");
    }

    void selectUnequalToValue(int value) throws IOException {
        System.out.println("Using no index...");
        long start = Instant.now().toEpochMilli();
        int filesRead = 0;
        for(int f = 1; f<100; f++){
            File file = new File("Project2Dataset\\F" + f + ".txt");
            filesRead++;
            InputStream is = new FileInputStream(file);
            for(int r = 0; r<100; r++) {

                byte[] tempBuffer = new byte[40];
                is.read(tempBuffer,0,40);
                String record = new String(tempBuffer);
                if(Integer.parseInt(record.substring(33,37)) != value){
                    System.out.println("Record: " + record);
                }
            }
            is.close();
        }
        long end = Instant.now().toEpochMilli();
        System.out.println("Files/Blocks read: " + filesRead);
        System.out.println("Total time = " + (end-start) + " milliseconds");
    }

}
