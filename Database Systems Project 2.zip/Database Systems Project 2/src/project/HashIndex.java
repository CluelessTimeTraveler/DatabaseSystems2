package project;

import java.util.ArrayList;
import java.util.HashMap;

public class HashIndex extends Index{
    private HashMap<Integer, ArrayList<RecordLocation>> index;
    public HashIndex() {
        this.index = new HashMap<>();
    }






    public void add(String record, RecordLocation location){
        char[] recordBytes = record.toCharArray();
        String randomV = "".concat(String.valueOf(recordBytes[33])).concat(String.valueOf(recordBytes[34])).concat(String.valueOf(recordBytes[35])).concat(String.valueOf(recordBytes[36]));

        ArrayList<RecordLocation> retrievedListOfLocations = index.get(Integer.parseInt(randomV));
        if(retrievedListOfLocations == null){
            ArrayList<RecordLocation> newList = new ArrayList<>();
            newList.add(location);
            index.put(Integer.parseInt(randomV), newList);
        }else{
            retrievedListOfLocations.add(location);
            index.put(Integer.parseInt(randomV), retrievedListOfLocations);
        }
    }

    public ArrayList<RecordLocation> get(int randomV){
        return index.get(randomV);
    }


}
